<?php
    require_once "connections/connection.php";

    session_start();

    if(empty($_SESSION['userid'])){
        header("Location: index.html");
    }
    else{
        $userid = $_SESSION['userid'];
        $username = $_SESSION['username'];

        if($userid == 6){
            header("Location: admin/dashboard.php");
        }else{
            echo '<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="utf-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="styles/style.css">
                <title>Tell</title>
                <meta name="description" content="Tell your story" />
                <meta property="og:locale" content="en_US" />
                <meta property="og:type" content="website" />
                <meta property="og:title" content="Tell" />
                <meta property="og:description" content="Tell your story" />
                <meta property="og:url" content="https://www.dreamteamarena.com/" />
                <meta property="og:site_name" content="Tell" />
                <!--<meta property="og:image" content="https://www.dreamteamarena.com/images/DreamTeamArenaLogo.png" />-->
                <meta property="og:image" content="images/qlogo.png" />
                <meta name="twitter:card" content="summary" />
                <meta name="twitter:description" content="Tell your story" />
                <meta name="twitter:title" content="Tell" />
                <!--<link rel="icon" type="image/png" href="https://www.dreamteamarena.com/images/DreamTeamArenaLogo.png">-->
                <link rel="icon" type="image/png" href="images/qlogo.png">
            </head>
            <body>
                <nav>
                    <span id="siteimage"></span>
                    <!--<div id="searchbtn"></div>-->
                    <div id="settingsbtn" onclick="toggleVisibility()"></div>
                    <div id="profilebtn" onclick="switchPage()"></div>
                </nav>
                <div id="tellus">
                    <div id="tellustfprofilebtn"></div>
                    <div id="tellustf" onclick="switchPage2()">Tell us...</div>
                </nav>
                <div id="tells">';
                // Function to get the time ago string
                function getTimeAgoString($interval) {
                    if ($interval->y > 0) {
                        return $interval->format("%y yrs ago");
                    } elseif ($interval->m > 0) {
                        return $interval->format("%m mnths ago");
                    } elseif ($interval->d > 0) {
                        return $interval->format("%d dys ago");
                    } elseif ($interval->h > 0) {
                        return $interval->format("%h hrs ago");
                    } elseif ($interval->i > 0) {
                        return $interval->format("a few min ago");
                    } else {
                        return "Just now";
                    }
                }

                // Check if the form has been submitted and a post ID is provided
                if (isset($_POST["promote"]) || isset($_POST["report"])) {
                    $postId = $_POST["post_id"]; // Adjust this to match your HTML form field name

                    if (isset($_POST["promote"])) {
                        // Update the promote count in the database
                        $sql = "UPDATE tellspost SET promote = promote + 1 WHERE postsid = ?";
                    } elseif (isset($_POST["report"])) {
                        // Update the report count in the database
                        $sql = "UPDATE tellspost SET report = report + 1 WHERE postsid = ?";
                    }

                    // Prepare and execute the update statement
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $postId);

                    if ($stmt->execute()) {
                        // Success, perform any additional actions if needed
                        echo"<script>
                            location.href='homepage.php';
                        </script>";
                    } else {
                        // Error handling
                        echo "Error updating post.";
                    }

                    $stmt->close();
                }

                // Fetch posts data from the database
                // Fetch posts data from the database
                $sql = "SELECT tp.postsid, tp.text, tp.userid, tp.date, tp.report, tu.username
                FROM tellspost tp
                JOIN tellsuser tu ON tp.userid = tu.userid
                ORDER BY tp.promote DESC LIMIT 20";  // Use proper column name instead of 'promote'

                $result = mysqli_query($conn, $sql);

                if ($result && mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $uname = $row['username'];  // You can replace this with actual username

                        $postId = $row['postsid'];

                        // Get the post text
                        $postText = $row['text'];

                        // Calculate time difference
                        $postDate = new DateTime($row['date']);
                        $currentDate = new DateTime();
                        $interval = $currentDate->diff($postDate);
                        $timeAgo = getTimeAgoString($interval);

                        // Generate HTML for each post
                        echo '<span id="tellspost">
                                <div id="tellspostdescription">
                                    <span id="username">' . $uname . '</span>
                                    <span id="time">' . $timeAgo . '</span>
                                </div>
                                <div id="tellsposttext" onclick="expand(this);">
                                    ' . $postText . '
                                </div>
                                <div id="actionbtn">
                                    <form action="homepage.php" method="post">
                                        <input type="hidden" name="post_id" value="' . $postId . '">
                                        <!--<button type="submit" id="promote" name="promote" class="actionbtnmenu">&nbsp</button>
                                        <button type="submit" id="report" name="report" class="actionbtnmenu">&nbsp</button>-->
                                        <span id="promote" class="actionbtnmenu" onclick="submitForm(`promote`, '.$postId.')">&nbsp</span>
                                        <span id="report" class="actionbtnmenu" onclick="submitForm(`report`, '.$postId.')">&nbsp</span>
                                    </form>
                                </div>
                            </span>';
                    }
                }

                // Close the database connection
                mysqli_close($conn);
                
                echo '
                </div>
                <div id="updateform">
                    <form method="post" id="acctform">
                        <img src="images/icons8-user-icon-ios-16-filled-96.png" alt="" srcset=""><br>
                        <input type="text" name="userid" id="userid" placeholder="userid" value="'.$userid.'" hidden><br/>
                        <img src="images/icons8-user-tanah-basah-basic-outline-32.png" alt="" srcset="" id="inputimage">
                        <input type="text" name="uname" id="uname" placeholder="Username">
                        <img src="images/icons8-password-material-outlined-32.png" alt="" srcset="" id="inputimage">
                        <input type="password" name="pword" id="pword" placeholder="Password">
                        <input type="submit" name="update" value="Update">
                    </form>
                </div>

                <script>
                    function expand(element) {
                        // Get the current value of -webkit-line-clamp for the clicked element
                        var lineClampValue = window.getComputedStyle(element).webkitLineClamp;

                        // Increment the line clamp value by 10 (assuming it`s a number)
                        var newLineClampValue = parseInt(lineClampValue) + 4;

                        // Set the new value of -webkit-line-clamp for the clicked element
                        element.style.webkitLineClamp = newLineClampValue;

                        var form = document.getElementById("updateform");
                        if (form.style.visibility === "visible") {
                            form.style.visibility = "hidden";
                        }
                    }
                    function toggleVisibility() {
                        var form = document.getElementById("updateform");
                        if (form.style.visibility === "visible") {
                            form.style.visibility = "hidden";
                        } else {
                            form.style.visibility = "visible";
                        }
                    }
                    function switchPage(){
                        location.href = "profile.php";
                    }
                    function switchPage2(){
                        location.href = "tellus.php";
                    }
                    function submitForm(action, postId) {
                        var form = document.createElement("form");
                        form.method = "post";
                        form.action = "homepage.php";
                    
                        var inputPostId = document.createElement("input");
                        inputPostId.type = "hidden";
                        inputPostId.name = "post_id";
                        inputPostId.value = postId;
                        form.appendChild(inputPostId);
                    
                        var inputAction = document.createElement("input");
                        inputAction.type = "hidden";
                        inputAction.name = action;
                        form.appendChild(inputAction);
                    
                        document.body.appendChild(form);
                        form.submit();
                    }
                    
                </script>

            </body>
            </html>';
        }
    }
?>