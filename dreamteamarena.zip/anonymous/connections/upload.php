<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once "connection.php";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $userid = $_POST["userid"];
    // Get data from the textarea
    $content = $_POST["txtfld"];

    // Prepare and execute an INSERT statement
    $stmt = $conn->prepare("INSERT INTO tellspost (text,userid) VALUES (?,?)");
    $stmt->bind_param("si", $content, $userid);

    if ($stmt->execute()) {
        $stmt->close();

        echo"<script>
            location.href='../homepage.php';
            alert('Told');
        </script>";
        
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    require_once "disconnection.php";
}
?>