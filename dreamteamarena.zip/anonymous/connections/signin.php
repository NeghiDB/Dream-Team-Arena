<?php
require_once "connection.php";

if (isset($_POST["signin"])){
    $username = $_POST["uname"];
    $password = $_POST["pword"];

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM tellsuser WHERE Binary username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result === false) {
        die('Query execution failed: ' . $stmt->error);
    }

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row["password"];

        if (password_verify($password, $hashedPassword)) {
            session_start();
            $_SESSION['userid'] = $row["userid"];
            $_SESSION['username'] = $row["username"];

            $currentDate = new DateTime();
            $userId = $_SESSION['userid']; // Get the user's ID from the session

            $sql = "UPDATE tellsuser SET logindate = '".$currentDate->format('Y-m-d H:i:s')."' WHERE userid = ".$userId;

            $result = mysqli_query($conn, $sql);

            if ($result) {
                $stmt->close();
                // Successfully updated the login date
                header("Location:../homepage.php");
                exit;
            } else {
                // Error handling
                echo "Error updating login date: " . mysqli_error($conn);
            }
        } else {
            header("Location:../indexx.html");
        }
    }
    else {
        header("Location:../indexx.html");
    }

    $stmt->close();
}
elseif (isset($_POST["signup"])){
    $username = $_POST["uname"];
    $password = $_POST["pword"];
    
    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Prepare and execute a parameterized INSERT statement
    $stmt = $conn->prepare("INSERT INTO tellsuser (username, password)
                            VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $hashedPassword);
    if ($stmt->execute()) {
        echo "<script>
        location.href='../index.html';
        alert('Account created successfully.');
        </script>";
    } elseif ($conn->errno == 1062) {
        echo "<script>
        location.href='../index.html';
        alert('The username has already been used.');
        </script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
elseif (isset($_POST["update"])) {
    $userid = $_POST['userid'];
    $username = $_POST["uname"];
    $password = $_POST["pword"];

    // Hash the password if provided and not empty
    $hashedPassword = !empty($password) ? password_hash($password, PASSWORD_DEFAULT) : null;

    // Fetch the existing data for the user
    $stmtSelect = $conn->prepare("SELECT username, password FROM tellsuser WHERE userid = ?");
    $stmtSelect->bind_param("i", $userid);
    $stmtSelect->execute();
    $stmtSelect->bind_result($existingUsername, $existingPassword);
    $stmtSelect->fetch();
    $stmtSelect->close();

    // Decide what to update
    $newUsername = !empty($username) ? $username : $existingUsername;
    $newPassword = !empty($hashedPassword) ? $hashedPassword : $existingPassword;

    // Prepare and execute a parameterized UPDATE statement
    $stmtUpdate = $conn->prepare("UPDATE tellsuser SET username = ?, password = ?
                                  WHERE userid = ?");
    $stmtUpdate->bind_param("ssi", $newUsername, $newPassword, $userid);

    if ($stmtUpdate->execute()) {
        echo "<script>
        location.href='../homepage.php';
        alert('Account details updated successfully.');
        </script>";
    } else {
        echo "Error: " . $stmtUpdate->error;
    }

    $stmtUpdate->close();
}



require_once "disconnection.php";
?>