<?php
    require_once "connections/connection.php";

    session_start();

    if(empty($_SESSION['userid'])){
        header("Location: index.html");
    }
    else{
        $userid = $_SESSION['userid'];
        $username = $_SESSION['username'];

        if($userid == 6){
            header("Location: admin/dashboard.php");
        }else{
            echo '<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="utf-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="styles/style.css">
                <title>Tell</title>
                <meta name="description" content="Tell your story" />
                <meta property="og:locale" content="en_US" />
                <meta property="og:type" content="website" />
                <meta property="og:title" content="Tell" />
                <meta property="og:description" content="Tell your story" />
                <meta property="og:url" content="https://www.dreamteamarena.com/" />
                <meta property="og:site_name" content="Tell" />
                <!--<meta property="og:image" content="https://www.dreamteamarena.com/images/DreamTeamArenaLogo.png" />-->
                <meta property="og:image" content="images/qlogo.png" />
                <meta name="twitter:card" content="summary" />
                <meta name="twitter:description" content="Tell your story" />
                <meta name="twitter:title" content="Tell" />
                <!--<link rel="icon" type="image/png" href="https://www.dreamteamarena.com/images/DreamTeamArenaLogo.png">-->
                <link rel="icon" type="image/png" href="images/qlogo.png">
            </head>
            <body>
                <nav>
                    <span id="backbtn" onclick="switchPage3()"></span>
                    <span id="navwriteup">Create Post</span>
                </nav>
                <div id="tells">
                    <form action="connections/upload.php" method="post">
                    <input type="text" name="userid" id="userid" placeholder="userid" value="'.$userid.'" hidden><br/>
                    <div id="txtfldspace">
                        <textarea name="txtfld" id="txtfld" cols="30" rows="10" placeholder="Tell us..."></textarea>
                    </div>
                    <button type="submit" id="tellsubmit">TELL</button>
                    </form>
                </div>
                <script>
                    function switchPage3(){
                        location.href = "homepage.php";
                    }
                </script>
                
            </body>
            </html>';
        }
    }
?>