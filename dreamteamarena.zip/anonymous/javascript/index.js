var form = document.getElementById("loginform");
function expand(element) {
    // Get the current value of -webkit-line-clamp for the clicked element
    var lineClampValue = window.getComputedStyle(element).webkitLineClamp;

    // Increment the line clamp value by 10 (assuming it's a number)
    var newLineClampValue = parseInt(lineClampValue) + 10;

    // Set the new value of -webkit-line-clamp for the clicked element
    element.style.webkitLineClamp = newLineClampValue;
}
function toggleVisibility() {
    if (form.style.visibility === "visible") {
        form.style.visibility = "hidden";
    } else {
        form.style.visibility = "visible";
    }
}
function toggleVisibility2() {
    var form = document.getElementById("msgIncorrect");
    form.style.visibility = "hidden";
}